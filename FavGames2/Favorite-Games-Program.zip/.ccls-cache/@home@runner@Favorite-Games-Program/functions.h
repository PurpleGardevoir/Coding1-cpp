#ifndef FUNCTIONS_H
#define FUNCTIONS_H

#include <vector>
#include <string>

// Function declarations
void Load(std::vector<std::string>& games);
void Add(std::vector<std::string>& games);
void Edit(std::vector<std::string>& games);
void Remove(std::vector<std::string>& games);
void Show(const std::vector<std::string>& games);
void Quit(const std::vector<std::string>& games);

#endif // FUNCTIONS_