#include "functions.h"
#include <iostream>
#include <fstream>
#include <algorithm>

using namespace std;

void Load(vector<string>& games) {
    ifstream file("games.txt");
    if (file.is_open()) {
        string game;
        while (getline(file, game)) {
            games.push_back(game);
        }
        file.close();
    }
}

void Add(vector<string>& games) {
    string game;
    cout << "What game would you like to add? ";
    getline(cin, game);
    games.push_back(game);
}

void Edit(vector<string>& games) {
    string game;
    cout << "What game would you like to edit? ";
    getline(cin, game);
    auto it = find(games.begin(), games.end(), game);
    if (it != games.end()) {
        cout << "What would you like to change it to? ";
        getline(cin, game);
        *it = game;
    } else {
        cout << "Game not found." << endl;
    }
}

void Remove(vector<string>& games) {
    string game;
    cout << "What game would you like to remove? ";
    getline(cin, game);
    auto it = find(games.begin(), games.end(), game);
    if (it != games.end()) {
        games.erase(it);
        cout << "Game removed." << endl;
    } else {
        cout << "Game not found." << endl;
    }
}

void Show(const vector<string>& games) {
    vector<string> sortedGames = games;
    sort(sortedGames.begin(), sortedGames.end());
    for (size_t i = 0; i < sortedGames.size(); ++i) {
        cout << i + 1 << ". " << sortedGames[i] << endl;
    }
}

void Quit(const vector<string>& games) {
    string input;
    cout << "Would you like to wipe the list or save to file? (wipe/save): ";
    getline(cin, input);
    if (input == "save") {
        ofstream file("games.txt");
        if (file.is_open()) {
            for (const auto& game : games) {
                file << game << endl;
            }
            file.close();
            cout << "Games saved to file." << endl;
        }
    } else if (input == "wipe") {
        ofstream file("games.txt", ofstream::out | ofstream::trunc);
        file.close();
        cout << "Games list wiped." << endl;
    }
}
