#include <iostream>
#include <vector>
#include <string>
#include "functions.h"

using namespace std;

int main() {
    vector<string> games = {"The Legend of Zelda", "Super Mario Odyssey"};
    string input;

    cout << "Welcome to the favorite games manager!" << endl;

    Load(games);

    while (true) {
        cout << "What would you like to do? (Add, Edit, Delete, Show, Quit): ";
        getline(cin, input);

        if (input == "Add" || input == "add") {
            Add(games);
        } else if (input == "Edit" || input == "edit") {
            Edit(games);
        } else if (input == "Delete" || input == "delete") {
            Remove(games);
        } else if (input == "Show" || input == "show") {
            Show(games);
        } else if (input == "Quit" || input == "quit") {
            Quit(games);
            cout << "Thank you for using the program!" << endl;
            return 0;
        } else {
            cout << "Invalid option. Please try again." << endl;
        }
    }

    return 0;
}
